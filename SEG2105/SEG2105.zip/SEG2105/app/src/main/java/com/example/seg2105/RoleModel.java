package com.example.seg2105;

public class RoleModel {
    public RoleModel(){

    }
}
